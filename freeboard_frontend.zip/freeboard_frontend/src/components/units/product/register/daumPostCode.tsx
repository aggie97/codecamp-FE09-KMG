import DaumPostcodeEmbed from "react-daum-postcode";

const DaumPostCode = () => {
  return <DaumPostcodeEmbed />;
};

export default DaumPostCode;
