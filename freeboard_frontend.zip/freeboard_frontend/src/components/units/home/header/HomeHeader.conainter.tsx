import HomeHeaderUI from "./HomeHeader.presenter";

const HomeHeader = () => {
  return <HomeHeaderUI />;
};

export default HomeHeader;
