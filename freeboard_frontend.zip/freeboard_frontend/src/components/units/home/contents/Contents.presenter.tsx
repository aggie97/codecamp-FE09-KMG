import styled from "@emotion/styled";

const ContentsUI = () => {
  return <Wrapper>contents</Wrapper>;
};

export default ContentsUI;

export const Wrapper = styled.div`
  padding-top: 50px;
  max-width: 1240px;
  width: 100%;
  margin: 0 auto;
`;
