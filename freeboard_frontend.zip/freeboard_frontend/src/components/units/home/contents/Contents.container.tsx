import ContentsUI from "./Contents.presenter";

const ContentsPage = () => {
  return <ContentsUI />;
};

export default ContentsPage;
