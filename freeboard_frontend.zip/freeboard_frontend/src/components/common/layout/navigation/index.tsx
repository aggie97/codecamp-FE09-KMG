import HomeNavigation from "../../../units/home/navigation/HomeNav.container";

const Navigation = () => {
  return <HomeNavigation />;
};
export default Navigation;
