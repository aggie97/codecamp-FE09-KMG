import HomeHeader from "../../../units/home/header/HomeHeader.conainter";
import Wrapper from "./intersectionObserver";

export default function Header() {
  return (
    <Wrapper>
      <HomeHeader />
    </Wrapper>
  );
}
