import MyFirebaseList from "../../src/components/units/myFirebase/list/FirebaseList.container";

const MyFirebasePage = () => {
  return (
    <div>
      <MyFirebaseList />
    </div>
  );
};

export default MyFirebasePage;
