import ProductDetail from "../../../src/components/units/product/detail/ProductDetail.container";

const ProductDetailPage = () => {
  return <ProductDetail />;
};

export default ProductDetailPage;
