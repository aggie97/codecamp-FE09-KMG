import ProductRegister from "../../../src/components/units/product/register/ProductRegister.container";

const ProductMutatePage = () => {
  return <ProductRegister />;
};

export default ProductMutatePage;
