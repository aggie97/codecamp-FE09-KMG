const Market = () => {
  return <div></div>;
};

export default Market;
