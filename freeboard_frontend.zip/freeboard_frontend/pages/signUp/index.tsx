import SignUp from "../../src/components/units/signUp";

const SignUpPage = () => {
  return <SignUp />;
};

export default SignUpPage;
