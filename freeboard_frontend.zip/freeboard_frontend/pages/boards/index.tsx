import BoardList from "../../src/components/units/board/list/BoardList.container";

const Home = () => {
  return (
    <>
      <BoardList />
    </>
  );
};

export default Home;
