import BoardRegister from "../../../src/components/units/board/register/BoardRegister.container";

export default function Home() {
  return <BoardRegister isEdit={false} />;
}
