import SignIn from "../../src/components/units/signIn";

const SignInPage = () => {
  return <SignIn />;
};

export default SignInPage;
