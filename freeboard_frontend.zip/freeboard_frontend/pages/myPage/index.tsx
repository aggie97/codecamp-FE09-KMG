import MyPage from "../../src/components/units/myPage";

const MyPageIn = () => {
  return <MyPage />;
};

export default MyPageIn;
